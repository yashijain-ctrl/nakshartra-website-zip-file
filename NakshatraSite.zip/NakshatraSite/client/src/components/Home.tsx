import { useEffect } from 'react';

import WhatsApp_Image_2025_08_27_at_16_20_33_b05f01b7 from "@assets/WhatsApp Image 2025-08-27 at 16.20.33_b05f01b7.jpg";

import WhatsApp_Image_2025_08_27_at_16_25_49_a8255a85 from "@assets/WhatsApp Image 2025-08-27 at 16.25.49_a8255a85.jpg";

import WhatsApp_Image_2025_08_27_at_16_28_52_4a317426 from "@assets/WhatsApp Image 2025-08-27 at 16.28.52_4a317426.jpg";

import WhatsApp_Image_2025_08_27_at_16_28_53_05d05b05 from "@assets/WhatsApp Image 2025-08-27 at 16.28.53_05d05b05.jpg";

import WhatsApp_Image_2025_08_27_at_16_28_52_36261431 from "@assets/WhatsApp Image 2025-08-27 at 16.28.52_36261431.jpg";

import WhatsApp_Image_2025_08_27_at_16_28_53_193dd688 from "@assets/WhatsApp Image 2025-08-27 at 16.28.53_193dd688.jpg";

import WhatsApp_Image_2025_08_27_at_16_52_09_462f12e8 from "@assets/WhatsApp Image 2025-08-27 at 16.52.09_462f12e8.jpg";

import WhatsApp_Image_2025_08_27_at_16_51_10_c496bd9e from "@assets/WhatsApp Image 2025-08-27 at 16.51.10_c496bd9e.jpg";

import WhatsApp_Image_2025_08_27_at_16_51_09_e5fdec70 from "@assets/WhatsApp Image 2025-08-27 at 16.51.09_e5fdec70.jpg";

import WhatsApp_Image_2025_08_27_at_16_51_10_5373bc7f from "@assets/WhatsApp Image 2025-08-27 at 16.51.10_5373bc7f.jpg";

export default function Home() {
  useEffect(() => {
    // Smooth scroll reveal animation
    function revealOnScroll() {
      const elements = document.querySelectorAll('.scroll-fade');
      elements.forEach(element => {
        const elementTop = element.getBoundingClientRect().top;
        const windowHeight = window.innerHeight;
        
        if (elementTop < windowHeight * 0.8) {
          element.classList.add('visible');
        }
      });
    }

    // Initial reveal and scroll listener
    revealOnScroll();
    const handleScroll = () => revealOnScroll();
    window.addEventListener('scroll', handleScroll);

    // Smooth scrolling for navigation
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const href = (anchor as HTMLAnchorElement).getAttribute('href');
        const target = document.querySelector(href || '');
        if (target) {
          target.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
          });
        }
      });
    });

    // Horizontal scroll behavior for explore section
    const exploreSection = document.querySelector('.horizontal-scroll') as HTMLElement;
    if (exploreSection) {
      let isDown = false;
      let startX: number;
      let scrollLeft: number;

      const handleMouseDown = (e: Event) => {
        const mouseEvent = e as MouseEvent;
        isDown = true;
        startX = mouseEvent.pageX - exploreSection.offsetLeft;
        scrollLeft = exploreSection.scrollLeft;
      };

      const handleMouseLeave = () => {
        isDown = false;
      };

      const handleMouseUp = () => {
        isDown = false;
      };

      const handleMouseMove = (e: Event) => {
        const mouseEvent = e as MouseEvent;
        if (!isDown) return;
        e.preventDefault();
        const x = mouseEvent.pageX - exploreSection.offsetLeft;
        const walk = (x - startX) * 2;
        exploreSection.scrollLeft = scrollLeft - walk;
      };

      exploreSection.addEventListener('mousedown', handleMouseDown);
      exploreSection.addEventListener('mouseleave', handleMouseLeave);
      exploreSection.addEventListener('mouseup', handleMouseUp);
      exploreSection.addEventListener('mousemove', handleMouseMove);

      return () => {
        window.removeEventListener('scroll', handleScroll);
        if (exploreSection) {
          exploreSection.removeEventListener('mousedown', handleMouseDown);
          exploreSection.removeEventListener('mouseleave', handleMouseLeave);
          exploreSection.removeEventListener('mouseup', handleMouseUp);
          exploreSection.removeEventListener('mousemove', handleMouseMove);
        }
      };
    }

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="starfield"></div>
      {/* Top Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-card/10 backdrop-blur-md border-b border-border/20">
        <div className="w-full px-8 py-4 flex justify-between items-center">
          {/* NAKSHATRA Branding - Extreme Left */}
          <div className="font-orbitron font-bold text-2xl futuristic-text text-primary pl-[25px] pr-[25px] ml-[0px] mr-[0px] mt-[0px] mb-[0px] pt-[8px] pb-[8px]">
            NAKSHATRA
          </div>
          
          {/* Right Side: Navigation Menu + Social Links - Far Right */}
          <div className="flex items-center space-x-16 mr-8">
            {/* Navigation Menu */}
            <div className="hidden md:flex space-x-8 font-medium">
              <a href="#home" className="font-montserrat text-sm font-medium nav-glow text-foreground/80" data-testid="nav-home">HOME</a>
              <a href="#explore" className="font-montserrat text-sm font-medium nav-glow text-foreground/80" data-testid="nav-explore">EXPLORE</a>
              <a href="#events" className="font-montserrat text-sm font-medium nav-glow text-foreground/80" data-testid="nav-events">EVENTS</a>
              <a href="#calendar" className="font-montserrat text-sm font-medium nav-glow text-foreground/80" data-testid="nav-calendar">CALENDAR</a>
              <a href="#about" className="font-montserrat text-sm font-medium nav-glow text-foreground/80" data-testid="nav-about">ABOUT</a>
              <a href="#gallery" className="font-montserrat text-sm font-medium nav-glow text-foreground/80" data-testid="nav-gallery">GALLERY</a>
              <a href="#contact" className="font-montserrat text-sm font-medium nav-glow text-foreground/80" data-testid="nav-contact">CONTACT</a>
            </div>
            
            {/* Social Links */}
            <div className="flex space-x-4">
              <a href="https://instagram.com" className="text-foreground/70 hover:text-primary transition-colors" data-testid="link-instagram">
                <i className="fab fa-instagram text-lg"></i>
              </a>
              <a href="https://youtube.com" className="text-foreground/70 hover:text-primary transition-colors" data-testid="link-youtube">
                <i className="fab fa-youtube text-lg"></i>
              </a>
              <a href="mailto:info@nakshatra.com" className="text-foreground/70 hover:text-primary transition-colors" data-testid="link-email">
                <i className="fas fa-envelope text-lg"></i>
              </a>
            </div>
          </div>
        </div>
      </nav>
      {/* Hero Section */}
      <section id="home" className="min-h-screen flex items-center justify-center px-6 lg:px-20 relative pt-20">
        <div className="max-w-4xl text-center">
          <div className="scroll-fade">
            <h1 className="font-orbitron font-black text-4xl md:text-5xl lg:text-6xl xl:text-7xl mb-6 leading-tight">
              Welcome to the{' '}
              <span className="gradient-text block mt-2">
                UNIVERSE
              </span>
            </h1>
            <h2 className="font-montserrat text-lg md:text-xl lg:text-2xl futuristic-text text-secondary mb-6">
              Nakshatra – Astronomy & Mathematics Society
            </h2>
            <p className="font-sans text-base md:text-lg lg:text-xl text-foreground/90 max-w-2xl mx-auto mb-10 leading-relaxed">
              Exploring the cosmos, one star at a time.
            </p>
          </div>
        </div>
        
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <i className="fas fa-chevron-down text-primary text-3xl opacity-70"></i>
        </div>
      </section>
      {/* Explore Section */}
      <section id="explore" className="py-20 px-6 lg:px-20">
        <div className="scroll-fade">
          <h2 className="font-orbitron font-bold text-4xl lg:text-5xl text-center mb-16 futuristic-text">
            EXPLORE
          </h2>
          
          <div className="horizontal-scroll overflow-x-auto pb-4">
            <div className="flex space-x-6 min-w-max">
              {/* Stars Card */}
              <div className="bg-card/30 backdrop-blur-sm rounded-xl p-6 border border-border/30 glow-on-hover min-w-[300px]">
                <img 
                  src={WhatsApp_Image_2025_08_27_at_16_52_09_462f12e8} 
                  alt="Beautiful star cluster in deep space" 
                  className="w-full h-48 object-cover rounded-lg mb-4" 
                />
                <h3 className="font-orbitron font-bold text-xl text-foreground mb-2">Stars</h3>
                <p className="text-muted-foreground">Cosmic beacons of light, shaping the universe</p>
              </div>

              {/* Planets Card */}
              <div className="bg-card/30 backdrop-blur-sm rounded-xl p-6 border border-border/30 glow-on-hover min-w-[300px]">
                <img 
                  src="https://images.unsplash.com/photo-1614313913007-2b4ae8ce32d6?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250" 
                  alt="Mars planetary surface from NASA imagery" 
                  className="w-full h-48 object-cover rounded-lg mb-4" 
                />
                <h3 className="font-orbitron font-bold text-xl text-foreground mb-2">Planets</h3>
                <p className="text-muted-foreground">New worlds of our solar system, waiting to be discovered</p>
              </div>

              {/* Nebulae Card */}
              <div className="bg-card/30 backdrop-blur-sm rounded-xl p-6 border border-border/30 glow-on-hover min-w-[300px]">
                <img 
                  src={WhatsApp_Image_2025_08_27_at_16_51_10_c496bd9e} 
                  alt="Colorful nebula with star formation regions" 
                  className="w-full h-48 object-cover rounded-lg mb-4" 
                />
                <h3 className="font-orbitron font-bold text-xl text-foreground mb-2">Black Holes</h3>
                <p className="text-muted-foreground">"Gravity's extremes, where space and time band into the unknowns"</p>
              </div>

              {/* Galaxies Card */}
              <div className="bg-card/30 backdrop-blur-sm rounded-xl p-6 border border-border/30 glow-on-hover min-w-[300px]">
                <img 
                  src={WhatsApp_Image_2025_08_27_at_16_51_09_e5fdec70} 
                  alt="Spiral galaxy showing cosmic structure" 
                  className="w-full h-48 object-cover rounded-lg mb-4" 
                />
                <h3 className="font-orbitron font-bold text-xl text-foreground mb-2">Galaxies</h3>
                <p className="text-muted-foreground">"Vast cosmic cities, home to billions of stars and mysteries untold" </p>
              </div>

              {/* Exoplanets Card */}
              <div className="bg-card/30 backdrop-blur-sm rounded-xl p-6 border border-border/30 glow-on-hover min-w-[300px]">
                <img 
                  src={WhatsApp_Image_2025_08_27_at_16_51_10_5373bc7f} 
                  alt="Exoplanet orbiting a distant star system" 
                  className="w-full h-48 object-cover rounded-lg mb-4" 
                />
                <h3 className="font-orbitron font-bold text-xl text-foreground mb-2">Exoplanets</h3>
                <p className="text-muted-foreground">"New worlds of our solar system, waiting to be discovered"</p>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* What We Do Section */}
      <section id="events" className="py-20 px-6 lg:px-20">
        <div className="scroll-fade">
          <h2 className="font-orbitron font-bold text-4xl lg:text-5xl text-center mb-16 futuristic-text">
            WHAT WE DO
          </h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {/* Stargazing Nights */}
            <div className="bg-card/20 backdrop-blur-sm rounded-xl p-6 border border-border/30 glow-on-hover">
              <div className="text-5xl mb-6 text-center">
                <i className="fas fa-eye text-primary" style={{textShadow: '0 0 15px hsla(217, 91%, 60%, 0.7)'}}></i>
              </div>
              <h3 className="font-orbitron font-bold text-xl text-center futuristic-text mb-4">Stargazing Nights</h3>
              <p className="text-muted-foreground text-center">Regular observation sessions to explore constellations and celestial phenomena</p>
            </div>

            {/* Rocket Building */}
            <div className="bg-card/20 backdrop-blur-sm rounded-xl p-6 border border-border/30 glow-on-hover">
              <div className="text-5xl mb-6 text-center">
                <i className="fas fa-rocket text-secondary" style={{textShadow: '0 0 15px hsla(270, 60%, 60%, 0.7)'}}></i>
              </div>
              <h3 className="font-orbitron font-bold text-xl text-center futuristic-text mb-4">Rocket Workshops</h3>
              <p className="text-muted-foreground text-center">Hands-on engineering sessions to build and launch model rockets</p>
            </div>

            {/* Space Quizzes */}
            <div className="bg-card/20 backdrop-blur-sm rounded-xl p-6 border border-border/30 glow-on-hover">
              <div className="text-5xl mb-6 text-center">
                <i className="fas fa-satellite text-accent" style={{textShadow: '0 0 15px hsla(260, 75%, 65%, 0.7)'}}></i>
              </div>
              <h3 className="font-orbitron font-bold text-xl text-center futuristic-text mb-4">Space Talks & Quizzes</h3>
              <p className="text-muted-foreground text-center">Interactive competitions and expert lectures on space science</p>
            </div>

            {/* Astrophotography */}
            <div className="bg-card/20 backdrop-blur-sm rounded-xl p-6 border border-border/30 glow-on-hover">
              <div className="text-5xl mb-6 text-center">
                <i className="fas fa-camera text-primary" style={{textShadow: '0 0 15px hsla(217, 91%, 60%, 0.7)'}}></i>
              </div>
              <h3 className="font-orbitron font-bold text-xl text-center futuristic-text mb-4">Astrophotography</h3>
              <p className="text-muted-foreground text-center">Capture the beauty of the night sky with professional techniques</p>
            </div>

            {/* Webathons */}
            <div className="bg-card/20 backdrop-blur-sm rounded-xl p-6 border border-border/30 glow-on-hover">
              <div className="text-5xl mb-6 text-center">
                <i className="fas fa-code text-secondary" style={{textShadow: '0 0 15px hsla(270, 60%, 60%, 0.7)'}}></i>
              </div>
              <h3 className="font-orbitron font-bold text-xl text-center futuristic-text mb-4">Space Hackathons</h3>
              <p className="text-muted-foreground text-center">Code for space exploration and astronomical data analysis</p>
            </div>

            {/* Mathematics */}
            <div className="bg-card/20 backdrop-blur-sm rounded-xl p-6 border border-border/30 glow-on-hover">
              <div className="text-5xl mb-6 text-center">
                <i className="fas fa-infinity text-accent" style={{textShadow: '0 0 15px hsla(260, 75%, 65%, 0.7)'}}></i>
              </div>
              <h3 className="font-orbitron font-bold text-xl text-center futuristic-text mb-4">Mathematical Modeling</h3>
              <p className="text-muted-foreground text-center">Apply mathematics to solve complex astronomical problems</p>
            </div>
          </div>
        </div>
      </section>
      {/* Astronomy Calendar Section */}
      <section id="calendar" className="py-20 px-6 lg:px-20">
        <div className="scroll-fade">
          <h2 className="font-orbitron font-bold text-4xl lg:text-5xl text-center mb-16 futuristic-text">
            ASTRONOMY CALENDAR
          </h2>
          
          <div className="max-w-4xl mx-auto">
            <div className="bg-card/20 backdrop-blur-sm rounded-xl p-8 border border-border/30">
              <div className="grid md:grid-cols-2 gap-8">
                <div>
                  <h3 className="font-montserrat font-semibold text-xl text-primary mb-4">This Month's Events</h3>
                  <div className="space-y-4">
                    <div className="flex items-start space-x-3">
                      <div className="text-secondary mt-1">
                        <i className="fas fa-calendar-day"></i>
                      </div>
                      <div>
                        <p className="font-medium text-foreground">Lunar Eclipse Observation</p>
                        <p className="text-sm text-muted-foreground">January 15, 2025 - 8:00 PM</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="text-secondary mt-1">
                        <i className="fas fa-calendar-day"></i>
                      </div>
                      <div>
                        <p className="font-medium text-foreground">Mars Opposition Viewing</p>
                        <p className="text-sm text-muted-foreground">January 22, 2025 - 9:30 PM</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="text-secondary mt-1">
                        <i className="fas fa-calendar-day"></i>
                      </div>
                      <div>
                        <p className="font-medium text-foreground">Constellation Workshop</p>
                        <p className="text-sm text-muted-foreground">January 28, 2025 - 7:00 PM</p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="font-montserrat font-semibold text-xl text-accent mb-4">Upcoming Highlights</h3>
                  <div className="space-y-4">
                    <div className="flex items-start space-x-3">
                      <div className="text-primary mt-1">
                        <i className="fas fa-star"></i>
                      </div>
                      <div>
                        <p className="font-medium text-foreground">Meteor Shower Peak</p>
                        <p className="text-sm text-muted-foreground">February 3-5, 2025</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="text-primary mt-1">
                        <i className="fas fa-satellite"></i>
                      </div>
                      <div>
                        <p className="font-medium text-foreground">ISS Flyover Sessions</p>
                        <p className="text-sm text-muted-foreground">Multiple dates in February</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* About Us Section */}
      <section id="about" className="py-20 px-6 lg:px-20">
        <div className="scroll-fade">
          <h2 className="font-orbitron font-bold text-4xl lg:text-5xl text-center mb-16 futuristic-text">
            ABOUT US
          </h2>
          
          <div className="max-w-4xl mx-auto text-center">
            <div className="bg-card/20 backdrop-blur-sm rounded-xl p-8 border border-border/30 mb-8">
              <img 
                src={WhatsApp_Image_2025_08_27_at_16_20_33_b05f01b7} 
                alt="Diverse group of college students working together on astronomy project" 
                className="w-full h-80 object-cover object-center rounded-lg mb-8" 
                data-testid="img-group-photo"
              />
              
              <p className="font-sans text-lg lg:text-xl text-foreground/90 leading-relaxed mb-6">
                Nakshatra is more than just an astronomy club – we're a community of curious minds united by our 
                fascination with the cosmos. Founded by passionate students, our society brings together people from 
                all backgrounds to explore space science, share knowledge, and inspire the next generation of 
                astronomers and space enthusiasts.
              </p>
              
              <p className="font-sans text-base text-muted-foreground">
                From hands-on telescope building to theoretical discussions about black holes, we create an environment 
                where learning meets wonder, and every clear night sky becomes an opportunity for discovery.
              </p>
            </div>
          </div>
        </div>
      </section>
      {/* Gallery Section */}
      <section id="gallery" className="py-20 px-6 lg:px-20">
        <div className="scroll-fade">
          <h2 className="font-orbitron font-bold text-4xl lg:text-5xl text-center mb-16 futuristic-text">
            GALLERY
          </h2>
          
          <div className="grid grid-cols-2 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            <img 
              src={WhatsApp_Image_2025_08_27_at_16_28_53_05d05b05} 
              alt="Horsehead Nebula - cosmic star formation region" 
              className="w-full h-56 object-cover rounded-lg glow-on-hover" 
            />
            
            <img 
              src={WhatsApp_Image_2025_08_27_at_16_28_53_193dd688} 
              alt="Spiral galaxy with luminous arms" 
              className="w-full h-56 object-cover rounded-lg glow-on-hover" 
            />
            
            <img 
              src="https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=400" 
              alt="Brilliant star clusters in Milky Way" 
              className="w-full h-56 object-cover rounded-lg glow-on-hover" 
            />
            
            <img 
              src="https://images.unsplash.com/photo-1614313913007-2b4ae8ce32d6?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=400" 
              alt="Mars surface captured by NASA rover" 
              className="w-full h-56 object-cover rounded-lg glow-on-hover" 
            />
            
            <img 
              src={WhatsApp_Image_2025_08_27_at_16_25_49_a8255a85} 
              alt="Advanced telescope pointing toward cosmos" 
              className="w-full h-56 object-cover rounded-lg glow-on-hover" 
            />
            
            <img 
              src={WhatsApp_Image_2025_08_27_at_16_28_52_4a317426} 
              alt="Earth rising over lunar horizon" 
              className="w-full h-56 object-cover rounded-lg glow-on-hover" 
            />
          </div>
        </div>
      </section>
      {/* Contact Section */}
      <section id="contact" className="py-20 px-6 lg:px-20">
        <div className="scroll-fade">
          <h2 className="font-orbitron font-bold text-4xl lg:text-5xl text-center mb-8 futuristic-text">
            CONTACT US
          </h2>
          
          <p className="font-sans text-xl text-center text-muted-foreground mb-16 max-w-2xl mx-auto">
            Ready to explore the stars with us?
          </p>
          
          <div className="max-w-4xl mx-auto">
            <div className="bg-card/20 backdrop-blur-sm rounded-xl p-8 border border-border/30 text-center">
              <div className="grid md:grid-cols-3 gap-8 mb-8">
                <div>
                  <div className="text-3xl text-primary mb-3">
                    <i className="fas fa-envelope"></i>
                  </div>
                  <h3 className="font-montserrat font-semibold text-lg text-foreground mb-2">Email</h3>
                  <p className="text-muted-foreground" data-testid="text-email">nakshatra@nsut.ac.in</p>
                </div>
                
                <div>
                  <div className="text-3xl text-secondary mb-3">
                    <i className="fab fa-instagram"></i>
                  </div>
                  <h3 className="font-montserrat font-semibold text-lg text-foreground mb-2">Instagram</h3>
                  <p className="text-muted-foreground" data-testid="text-instagram">@nakshatra_nsut</p>
                </div>
                
                <div>
                  <div className="text-3xl text-accent mb-3">
                    <i className="fab fa-youtube"></i>
                  </div>
                  <h3 className="font-montserrat font-semibold text-lg text-foreground mb-2">YouTube</h3>
                  <p className="text-muted-foreground" data-testid="text-youtube">Nakshatra NSUT</p>
                </div>
              </div>
              
              <button 
                className="bg-gradient-to-r from-primary to-secondary hover:from-primary/80 hover:to-secondary/80 text-primary-foreground px-8 py-4 rounded-lg font-montserrat font-semibold text-lg transition-all glow-on-hover"
                data-testid="button-sign-up"
              >
                <i className="fas fa-rocket mr-2"></i>Sign Up to Explore
              </button>
            </div>
          </div>
        </div>
      </section>
      {/* Footer */}
      <footer className="py-8 px-6 lg:px-20 border-t border-border/30">
        <div className="text-center text-muted-foreground font-sans">
          <p>© 2025 Nakshatra Astronomy & Mathematics Society, NSUT</p>
        </div>
      </footer>
    </div>
  );
}
