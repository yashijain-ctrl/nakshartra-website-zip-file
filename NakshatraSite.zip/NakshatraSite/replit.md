# Overview

This is a modern full-stack web application built for the Nakshatra Astronomy & Mathematics Society at NSUT. The project is a single-page scrolling website with a cosmic, space-themed design inspired by NASA's aesthetic. It features a clean, professional interface with smooth animations and a dark space theme using bluish-purple color schemes.

The application uses a monorepo structure with separate client and server directories, implementing a modern tech stack with React for the frontend, Express.js for the backend, and PostgreSQL with Drizzle ORM for data persistence. The design system is built with shadcn/ui components and Tailwind CSS for consistent styling.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The client-side application is built using **React 18** with **TypeScript** in a single-page application (SPA) format. The architecture follows a component-based design pattern using modern React patterns including hooks and context for state management.

**UI Framework**: The application uses **shadcn/ui** component library built on top of **Radix UI primitives**, providing accessible and customizable components. The styling system uses **Tailwind CSS** with custom CSS variables for theming, implementing a dark space theme with cosmic color schemes.

**State Management**: The application uses **TanStack Query (React Query)** for server state management, providing caching, synchronization, and background updates. Local state is managed through React's built-in hooks.

**Typography**: Custom font integration includes Orbitron for futuristic headings and Poppins/Montserrat for body text, maintaining the space-themed aesthetic throughout the application.

## Backend Architecture
The server uses **Express.js** with **TypeScript** in ESM format, providing a RESTful API architecture. The backend implements a layered architecture with clear separation of concerns:

**Route Layer**: API endpoints are prefixed with `/api` and organized in a centralized routing system through the `registerRoutes` function.

**Storage Layer**: Implements a storage interface pattern with both in-memory and database implementations. The `IStorage` interface defines CRUD operations, currently implemented with `MemStorage` for development and designed to support database storage in production.

**Development Setup**: Uses **Vite** for development with hot module replacement (HMR) and includes custom middleware for request logging and error handling.

## Database Architecture
The application uses **PostgreSQL** as the primary database with **Drizzle ORM** for type-safe database operations and migrations.

**Schema Definition**: Database schemas are defined in TypeScript using Drizzle's schema builder, with automatic type inference for full type safety. The current schema includes a users table with UUID primary keys and unique constraints.

**Migration System**: Uses Drizzle Kit for database migrations with configurations stored in `drizzle.config.ts`. Migrations are stored in a dedicated migrations directory.

**Type Safety**: Implements **Zod** schemas for runtime validation combined with Drizzle's type inference, ensuring data consistency between client and server.

## Build and Deployment
The application uses a dual build system:
- **Frontend Build**: Vite handles the client-side bundling with React and TypeScript compilation
- **Backend Build**: esbuild compiles the Express server for production deployment

**Development Workflow**: Supports hot reloading for both client and server code, with automatic TypeScript compilation and error reporting.

# External Dependencies

## Database Services
- **Neon Database**: PostgreSQL-compatible serverless database using `@neondatabase/serverless` for connection pooling and edge compatibility
- **Drizzle ORM**: Type-safe database toolkit with PostgreSQL dialect support
- **connect-pg-simple**: PostgreSQL session store for Express sessions

## UI and Styling
- **Radix UI**: Comprehensive set of accessible, unstyled UI primitives for React
- **Tailwind CSS**: Utility-first CSS framework with custom configuration for the space theme
- **shadcn/ui**: Pre-built component library built on Radix UI with consistent design system
- **Google Fonts**: External font loading for Orbitron, Poppins, and Montserrat typefaces
- **Font Awesome**: Icon library for UI elements and social media icons

## Development and Build Tools
- **Vite**: Fast build tool and development server with React support
- **esbuild**: Fast JavaScript/TypeScript bundler for server-side code
- **TypeScript**: Static typing for both client and server code
- **Replit Integration**: Development environment plugins for runtime error handling and cartographer support

## Form and Data Management
- **React Hook Form**: Performant forms library with minimal re-renders
- **TanStack Query**: Powerful data synchronization for server state management
- **Zod**: TypeScript-first schema validation for runtime type checking
- **date-fns**: Modern JavaScript date utility library

## Animation and Interaction
- **Embla Carousel**: Lightweight carousel library for React
- **class-variance-authority**: Utility for creating variant-based component APIs
- **clsx**: Utility for constructing className strings conditionally